#!/usr/bin/env python3
"""
Seeded sample-data generator for the capstone:
  "Network Operations and Customer Service Intelligence" (telecom, data engineering)

Run:   python3 generate_telecom_data.py --out output --seed 42

Approach
  1. Generate CLEAN "truth" data from shared master data (sites, elements, subscribers, plans).
  2. Plant 3 major + 13 minor network incidents that ripple through ALL sources
     (alarms, usage events, CDRs, complaints, incident PDFs).
  3. Corrupt the clean data on purpose (duplicates, drift, missing intervals, corrupt payloads,
     layout change, messy identifiers) and write every injected fault to ground_truth/fault_ledger.csv.

Time convention: business day = IST (UTC+05:30). Day files are named by IST date.
Window: 2026-09-01 .. 2026-09-14 (14 days).
"""
import argparse
import json
import os
import random
import shutil
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

SEED = 42
N_SITES = 50
N_SUBS = 2000
DAYS = 14
DRIFT_DAY = 7  # 0-based day index -> usage events switch to schema v2 from 2026-09-08
IST = timezone(timedelta(hours=5, minutes=30))
UTC = timezone.utc
START_IST = datetime(2026, 9, 1, tzinfo=IST)
START_UTC_NAIVE = pd.Timestamp("2026-08-31 18:30:00")  # 2026-09-01 00:00 IST in UTC
IST_OFFSET = pd.Timedelta(hours=5, minutes=30)

LOCALITIES = [
    "Indiranagar", "Koramangala", "MG Road", "Whitefield", "Jayanagar", "HSR Layout", "Marathahalli",
    "Electronic City", "Hebbal", "Yelahanka", "Malleshwaram", "Rajajinagar", "BTM Layout", "JP Nagar",
    "Banashankari", "Basavanagudi", "Bellandur", "Sarjapur Road", "KR Puram", "Domlur", "Ulsoor",
    "Frazer Town", "Richmond Town", "Shivajinagar", "Vijayanagar", "Yeshwanthpur", "Peenya", "Kengeri",
    "Bommanahalli", "Hennur", "Banaswadi", "CV Raman Nagar", "Kalyan Nagar", "RT Nagar", "Sadashivanagar",
    "Lalbagh", "Wilson Garden", "Basaveshwaranagar", "Nagarbhavi", "Jalahalli", "Mahadevapura",
    "Brookefield", "Kadugodi", "Varthur", "Hosur Road", "Bannerghatta Road", "Kanakapura Road",
    "Devanahalli", "Vidyaranyapura", "Thanisandra",
]
assert len(LOCALITIES) == N_SITES
REGIONS = ["North", "South", "East", "West", "Central"]

PLANS = [  # plan_id, name, segment, monthly_fee, incl_min, incl_mb, rate_per_min, rate_per_mb
    ("PL01", "Prepaid Lite", "PREPAID", 149, 200, 6000, 1.00, 0.25),
    ("PL02", "Prepaid Plus", "PREPAID", 299, 600, 20000, 0.80, 0.20),
    ("PL03", "Postpaid Standard", "POSTPAID", 499, 1500, 40000, 0.60, 0.15),
    ("PL04", "Postpaid Premium", "POSTPAID", 799, 3000, 100000, 0.50, 0.10),
    ("PL05", "Enterprise Basic", "ENTERPRISE", 1299, 5000, 150000, 0.40, 0.08),
    ("PL06", "Enterprise Unlimited", "ENTERPRISE", 1999, 20000, 400000, 0.30, 0.05),
]

KIND_INFO = {
    "fiber_cut": ("Backhaul fiber cut caused by third-party road excavation",
                  "Fiber spliced by field team; link restored and site brought back into service"),
    "power_failure": ("Mains power failure with battery bank depleted",
                      "Diesel generator deployed and battery bank replaced"),
    "software_upgrade_fault": ("Faulty software upgrade on the baseband unit caused repeated cell restarts",
                               "Rolled back to the previous software version"),
    "hardware_overtemp": ("Cooling fan failure triggered over-temperature protection",
                          "Cooling fan unit replaced"),
    "clock_sync": ("GPS timing source lost causing clock synchronisation errors",
                   "GPS antenna realigned and timing source restored"),
    "antenna_vswr": ("Water ingress in antenna feeder connector causing high VSWR",
                     "Connector resealed and replaced"),
    "link_flap": ("Microwave backhaul link flapping due to heavy rain fade",
                  "Link parameters retuned after rain subsided"),
}
MINOR_KINDS = ["hardware_overtemp", "clock_sync", "antenna_vswr", "link_flap"]
MINOR_ALARM = {  # kind -> (element, alarm_type, probable_cause)
    "hardware_overtemp": ("RAN", "HIGH_TEMP", "Cabinet temperature above threshold"),
    "clock_sync": ("RAN", "CLOCK_SYNC_LOSS", "Loss of GPS timing reference"),
    "antenna_vswr": ("RAN", "HIGH_VSWR", "Reflected power above threshold"),
    "link_flap": ("RTR", "LINK_FLAP", "Microwave link up/down transitions"),
}
BASE_ALARMS = {  # element -> list of (alarm_type, severity, cause)
    "RAN": [("HIGH_TEMP", "MINOR", "Cabinet temperature above threshold"),
            ("CLOCK_SYNC_LOSS", "MINOR", "Loss of GPS timing reference"),
            ("HIGH_VSWR", "WARNING", "Reflected power above threshold"),
            ("CELL_DEGRADED", "MAJOR", "Cell performance degraded")],
    "RTR": [("LINK_FLAP", "MINOR", "Link up/down transitions"),
            ("HIGH_CPU", "WARNING", "Router CPU above threshold"),
            ("PACKET_LOSS", "MAJOR", "Packet loss above threshold")],
    "PWR": [("BATTERY_LOW", "WARNING", "Battery voltage low"),
            ("MAINS_FLUCTUATION", "MINOR", "Mains voltage fluctuation")],
}
HOUR_W = np.array([1, .6, .4, .3, .4, .8, 2, 4, 6, 7, 7, 7, 7, 6, 6, 6, 6, 7, 8, 9, 9, 8, 5, 2], float)


# ----------------------------------------------------------------------------- helpers
class Ledger:
    COLS = ["fault_type", "source", "file", "record_key", "detail"]

    def __init__(self):
        self.rows = []

    def add(self, ftype, source, file, key, detail=""):
        self.rows.append((ftype, source, file, str(key), detail))

    def add_many(self, ftype, source, files, keys, detail=""):
        for f, k in zip(files, keys):
            self.rows.append((ftype, source, f, str(k), detail))

    def write(self, path):
        df = pd.DataFrame(self.rows, columns=self.COLS)
        df.insert(0, "fault_id", [f"F{i + 1:05d}" for i in range(len(df))])
        df.to_csv(path, index=False)
        return df


def utc_naive(dt):
    return pd.Timestamp(dt.astimezone(UTC).replace(tzinfo=None))


def fmt_z(dt):
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def fmt_ist_off(dt):
    return dt.astimezone(IST).strftime("%Y-%m-%dT%H:%M:%S+05:30")


def day_str(d):
    return (datetime(2026, 9, 1) + timedelta(days=int(d))).strftime("%Y%m%d")


def canon_site(n):
    return f"CELL-{int(n):04d}"


def msisdn_variants_vec(ms, rng, p_non=0.15):
    s = pd.Series(ms).astype(str)
    out = s.copy()
    non = rng.random(len(s)) < p_non
    k = rng.integers(0, 4, len(s))
    m = non & (k == 0); out[m] = "+" + s[m]
    m = non & (k == 1); out[m] = s[m].str[2:]
    m = non & (k == 2); out[m] = "+91 " + s[m].str[2:7] + " " + s[m].str[7:]
    m = non & (k == 3); out[m] = "+91-" + s[m].str[2:]
    return out.to_numpy(), int(non.sum())


def site_variants_vec(site_nos, rng, p_non=0.2):
    n = pd.Series(site_nos).astype(int)
    out = "CELL-" + n.astype(str).str.zfill(4)
    non = rng.random(len(n)) < p_non
    k = rng.integers(0, 4, len(n))
    m = non & (k == 0); out[m] = "cell_" + n[m].astype(str)
    m = non & (k == 1); out[m] = "CELL" + n[m].astype(str).str.zfill(4)
    m = non & (k == 2); out[m] = "CELL-" + n[m].astype(str).str.zfill(3)
    m = non & (k == 3); out[m] = "Cell-" + n[m].astype(str).str.zfill(4)
    return out.to_numpy(), int(non.sum())


def msisdn_variant(m, R):
    x = R.random()
    if x < .85: return m
    if x < .91: return "+" + m
    if x < .95: return m[2:]
    if x < .98: return f"+91 {m[2:7]} {m[7:]}"
    return f"+91-{m[2:]}"


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="output")
    ap.add_argument("--seed", type=int, default=SEED)
    a = ap.parse_args()
    out = a.out
    rng = np.random.default_rng(a.seed)
    R = random.Random(a.seed)
    if os.path.exists(out):
        shutil.rmtree(out)
    D = {k: os.path.join(out, k) for k in [
        "masters", "structured/cdr", "structured/billing", "semi_structured/alarms",
        "semi_structured/usage_events", "unstructured/complaints", "unstructured/incident_reports",
        "unstructured/service_agreements", "ground_truth"]}
    for p in D.values():
        os.makedirs(p)
    L = Ledger()
    summary = {}

    # ---------------------------------------------------------------- masters
    site_nos = np.arange(1, N_SITES + 1)
    sites = pd.DataFrame({
        "cell_site_id": [canon_site(n) for n in site_nos],
        "site_name": LOCALITIES,
        "region": [REGIONS[(n - 1) % 5] for n in site_nos],
        "latitude": np.round(12.85 + rng.random(N_SITES) * 0.25, 5),
        "longitude": np.round(77.45 + rng.random(N_SITES) * 0.30, 5),
        "technology": rng.choice(["4G", "5G"], N_SITES, p=[.6, .4]),
        "vendor": rng.choice(["Ericsson", "Nokia", "Samsung"], N_SITES),
        "commissioned_date": [(datetime(2018, 1, 1) + timedelta(days=int(d))).strftime("%Y-%m-%d")
                              for d in rng.integers(0, 2800, N_SITES)],
        "status": "ACTIVE",
    })
    sites.to_csv(f"{D['masters']}/cell_site_master.csv", index=False)

    el_rows = []
    for n, tech, vendor in zip(site_nos, sites.technology, sites.vendor):
        for code, etype, model in [("RAN", "RAN", "gNodeB" if tech == "5G" else "eNodeB"),
                                   ("RTR", "ROUTER", "AggRouter"), ("PWR", "POWER", "RectifierSystem")]:
            el_rows.append((f"EL-{n:04d}-{code}", canon_site(n), etype, model, vendor))
    pd.DataFrame(el_rows, columns=["element_id", "cell_site_id", "element_type", "model", "vendor"]) \
        .to_csv(f"{D['masters']}/network_element_master.csv", index=False)

    plans = pd.DataFrame(PLANS, columns=["plan_id", "plan_name", "segment", "monthly_fee_inr",
                                         "included_minutes", "included_mb", "rate_per_min_inr", "rate_per_mb_inr"])
    plans.to_csv(f"{D['masters']}/plan_rate_card.csv", index=False)

    w = rng.lognormal(0, 0.4, N_SITES)
    for s in (17, 8, 31):
        w[s - 1] *= 2.0
    w /= w.sum()
    home_site = rng.choice(site_nos, size=N_SUBS, p=w)
    ms_set = set()
    while len(ms_set) < N_SUBS:
        ms_set.add(f"91{rng.integers(6, 10)}{rng.integers(0, 10 ** 9):09d}")
    msisdns = np.array(sorted(ms_set))
    rng.shuffle(msisdns)
    seg = rng.choice(["PREPAID", "POSTPAID", "ENTERPRISE"], N_SUBS, p=[.6, .3, .1])
    plan_for = {"PREPAID": ["PL01", "PL02"], "POSTPAID": ["PL03", "PL04"], "ENTERPRISE": ["PL05", "PL06"]}
    plan_id = np.array([R.choice(plan_for[s]) for s in seg])
    subs = pd.DataFrame({
        "subscriber_id": [f"SUB{i + 1:06d}" for i in range(N_SUBS)],
        "msisdn": msisdns, "segment": seg, "plan_id": plan_id,
        "home_cell_site_id": [canon_site(s) for s in home_site],
        "region": [REGIONS[(s - 1) % 5] for s in home_site],
        "activation_date": [(datetime(2019, 1, 1) + timedelta(days=int(d))).strftime("%Y-%m-%d")
                            for d in rng.integers(0, 2800, N_SUBS)],
        "status": "ACTIVE",
    })
    subs.to_csv(f"{D['masters']}/subscriber_master.csv", index=False)
    subs_by_site = {}
    for i, s in enumerate(home_site):
        subs_by_site.setdefault(int(s), []).append(i)

    # ---------------------------------------------------------------- incidents
    MAJOR = [
        (17, datetime(2026, 9, 3, 14, 0, tzinfo=IST), datetime(2026, 9, 3, 16, 30, tzinfo=IST), "fiber_cut", 0),
        (8, datetime(2026, 9, 7, 2, 0, tzinfo=IST), datetime(2026, 9, 7, 5, 0, tzinfo=IST), "power_failure", 20),
        (31, datetime(2026, 9, 11, 18, 0, tzinfo=IST), datetime(2026, 9, 11, 20, 30, tzinfo=IST),
         "software_upgrade_fault", 0),
    ]
    incs = [dict(site=s, start=t0, end=t1, kind=k, severity="MAJOR", impact_start=t0 + timedelta(minutes=off))
            for s, t0, t1, k, off in MAJOR]
    used = {17, 8, 31}
    while len(incs) < 16:
        s = R.randint(1, N_SITES)
        if s in used:
            continue
        used.add(s)
        t0 = START_IST + timedelta(days=R.randint(0, DAYS - 1), hours=R.randint(8, 21),
                                   minutes=R.choice([0, 15, 30, 45]))
        incs.append(dict(site=s, start=t0, end=t0 + timedelta(minutes=R.choice([40, 50, 60, 75, 90])),
                         kind=R.choice(MINOR_KINDS), severity="MINOR", impact_start=t0))
    incs.sort(key=lambda x: x["start"])
    for i, inc in enumerate(incs):
        inc["id"] = f"INC-{i + 1:04d}"
        inc["root_cause"], inc["resolution"] = KIND_INFO[inc["kind"]]
        inc["impacted"] = len(subs_by_site.get(inc["site"], []))
        inc["day"] = (inc["start"].date() - START_IST.date()).days
        inc["layout"] = "v2" if inc["day"] >= DRIFT_DAY else "v1"
        inc["file"] = f"incident_report_{inc['id']}.pdf"
    pd.DataFrame([{
        "incident_id": i["id"], "cell_site_id": canon_site(i["site"]), "site_name": LOCALITIES[i["site"] - 1],
        "start_ist": fmt_ist_off(i["start"]), "end_ist": fmt_ist_off(i["end"]),
        "impact_start_ist": fmt_ist_off(i["impact_start"]), "severity": i["severity"], "incident_kind": i["kind"],
        "root_cause": i["root_cause"], "resolution_action": i["resolution"],
        "est_customers_impacted": i["impacted"], "report_layout": i["layout"], "report_file": i["file"],
    } for i in incs]).to_csv(f"{D['ground_truth']}/incident_truth.csv", index=False)

    # ---------------------------------------------------------------- CDR truth
    act = rng.lognormal(0, 0.6, N_SUBS) * np.where(seg == "PREPAID", 1.0, np.where(seg == "POSTPAID", 1.3, 1.5))
    counts = rng.poisson(lam=7 * act[:, None] * np.ones((1, DAYS)))
    flat_sub = np.repeat(np.repeat(np.arange(N_SUBS), DAYS), counts.ravel())
    flat_day = np.repeat(np.tile(np.arange(DAYS), N_SUBS), counts.ravel())
    n = len(flat_sub)
    hw = HOUR_W / HOUR_W.sum()
    hour = rng.choice(24, size=n, p=hw)
    secs = flat_day * 86400 + hour * 3600 + rng.integers(0, 3600, n)
    ctype = rng.choice(["VOICE", "SMS", "DATA"], size=n, p=[.35, .25, .40])
    dur = np.where(ctype == "VOICE", np.maximum(5, rng.lognormal(4.6, 0.9, n)),
                   np.where(ctype == "DATA", rng.lognormal(6, 0.8, n), 0)).astype(int)
    mb = np.where(ctype == "DATA", np.round(rng.lognormal(3.0, 1.0, n), 2), 0.0)
    site = home_site[flat_sub].copy()
    nb = rng.random(n) < 0.2
    for r in range(5):
        cand = np.array([s for s in range(1, N_SITES + 1) if (s - 1) % 5 == r])
        m = nb & ((site - 1) % 5 == r)
        site[m] = rng.choice(cand, size=int(m.sum()))
    other = pd.Series(rng.integers(0, 2 ** 32, n)).map(lambda v: f"{v:08x}").to_numpy()
    order = np.argsort(secs, kind="stable")
    t = pd.DataFrame({
        "sub": flat_sub[order], "day": flat_day[order], "secs": secs[order], "call_type": ctype[order],
        "duration_sec": dur[order], "data_mb": mb[order], "site_no": site[order], "other_party_hash": other[order],
    })
    t["start_utc"] = START_UTC_NAIVE + pd.to_timedelta(t.secs, unit="s")
    # outages genuinely suppress traffic (this is NOT a fault, it is the real-world effect)
    drop = np.zeros(len(t), bool)
    for inc in incs:
        if inc["severity"] != "MAJOR":
            continue
        m = (t.site_no == inc["site"]) & (t.start_utc >= utc_naive(inc["impact_start"])) & \
            (t.start_utc < utc_naive(inc["end"]) + pd.Timedelta(minutes=30))
        drop |= (m & (rng.random(len(t)) > 0.1)).to_numpy()
    t = t[~drop].reset_index(drop=True)
    t["cdr_id"] = [f"CDR{i + 1:09d}" for i in range(len(t))]
    t["msisdn"] = msisdns[t["sub"]]
    t["period"] = np.where(t.day < 7, 1, 2)
    t[["cdr_id", "msisdn", "call_type", "start_utc", "duration_sec", "data_mb", "site_no", "other_party_hash"]] \
        .assign(cell_site_id=lambda d: d.site_no.map(canon_site)) \
        .drop(columns="site_no").to_csv(f"{D['ground_truth']}/cdr_clean_truth.csv.gz", index=False)
    summary["cdr_truth_rows"] = len(t)

    # ---------------------------------------------------------------- billing (from truth)
    voice = t[t.call_type == "VOICE"]
    g_voice = voice.groupby(["sub", "period"]).agg(billed_calls=("cdr_id", "count"),
                                                    cdr_voice_sec=("duration_sec", "sum"),
                                                    billed_minutes=("duration_sec", lambda x: int(np.ceil(x / 60).sum())))
    g_data = t.groupby(["sub", "period"]).data_mb.sum().rename("billed_mb")
    g_sms = t[t.call_type == "SMS"].groupby(["sub", "period"]).size().rename("billed_sms")
    idx = pd.MultiIndex.from_product([range(N_SUBS), [1, 2]], names=["sub", "period"])
    b = pd.DataFrame(index=idx).join(g_voice).join(g_data).join(g_sms).fillna(0).reset_index()
    for c in ["billed_calls", "cdr_voice_sec", "billed_minutes", "billed_sms"]:
        b[c] = b[c].astype(int)
    b["billed_mb"] = b.billed_mb.round(2)
    b["true_cdr_minutes"] = (b.cdr_voice_sec / 60).round(2)
    b["true_cdr_mb"] = b.billed_mb
    b["bill_id"] = [f"BILL-P{p}-{s + 1:06d}" for s, p in zip(b["sub"], b.period)]
    pl = plans.set_index("plan_id")
    b["plan_id"] = plan_id[b["sub"]]
    b["flag"] = ""
    ov = rng.random(len(b)) < 0.03
    ov &= (b.billed_mb > 0).to_numpy()
    fac = rng.uniform(1.15, 1.40, len(b))
    b.loc[ov, "billed_mb"] = (b.loc[ov, "billed_mb"] * fac[ov]).round(2)
    b.loc[ov, "flag"] = "billing_overcharge"
    for bid, f in zip(b.loc[ov, "bill_id"], fac[ov]):
        L.add("billing_overcharge", "BILLING", "billing_extract", bid, f"billed_mb inflated x{f:.2f}")
    un = (rng.random(len(b)) < 0.01) & ~ov & (b.billed_minutes > 5).to_numpy()
    b.loc[un, "billed_minutes"] = (b.loc[un, "billed_minutes"] * 0.8).astype(int)
    b.loc[un, "flag"] = "billing_undercharge"
    for bid in b.loc[un, "bill_id"]:
        L.add("billing_undercharge", "BILLING", "billing_extract", bid, "billed_minutes reduced by 20%")
    fee_w = b.plan_id.map(pl.monthly_fee_inr) * 7 / 28
    inc_min_w = b.plan_id.map(pl.included_minutes) * 7 / 28
    inc_mb_w = b.plan_id.map(pl.included_mb) * 7 / 28
    b["amount_inr"] = (fee_w + np.maximum(0, b.billed_minutes - inc_min_w) * b.plan_id.map(pl.rate_per_min_inr)
                       + np.maximum(0, b.billed_mb - inc_mb_w) * b.plan_id.map(pl.rate_per_mb_inr)).round(2)
    b["msisdn"] = msisdns[b["sub"]]

    # ---------------------------------------------------------------- CDR faults + write
    t["lost"] = False
    lost = ((t.day == 4) & (rng.random(len(t)) < 0.25)) | (rng.random(len(t)) < 0.0005)
    t.loc[lost, "lost"] = True
    for cid, d in zip(t.loc[lost, "cdr_id"], t.loc[lost, "day"]):
        L.add("cdr_record_lost", "CDR", f"cdr_{day_str(d)}.csv", cid,
              "record exists in truth but is absent from delivered file" + (" (partial file day)" if d == 4 else ""))
    c = t[~t.lost].reset_index(drop=True)
    fc = rng.choice(3, size=len(c), p=[.70, .22, .08])
    iso = c.start_utc.dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    ist = (c.start_utc + IST_OFFSET).dt.strftime("%d/%m/%Y %H:%M:%S")
    ep = ((c.start_utc - pd.Timestamp("1970-01-01")).dt.total_seconds().astype(int)).astype(str)
    c["start_time"] = np.select([fc == 0, fc == 1], [iso, ist], ep)
    L.add("timestamp_format_mix", "CDR", "ALL", "*",
          f"iso_utc={int((fc == 0).sum())}, ist_naive_dd/mm/yyyy={int((fc == 1).sum())}, epoch_seconds={int((fc == 2).sum())}")
    c["msisdn_out"], nv = msisdn_variants_vec(c.msisdn, rng, 0.15)
    L.add("msisdn_format_variant", "CDR", "ALL", "*", f"{nv} rows with non-canonical MSISDN format")
    c["site_out"], nv = site_variants_vec(c.site_no, rng, 0.20)
    L.add("cell_site_id_format_variant", "CDR", "ALL", "*", f"{nv} rows with non-canonical cell_site_id")
    c["dur_out"] = c.duration_sec.astype("Int64")
    nm = (rng.random(len(c)) < 0.003)
    c.loc[nm, "site_out"] = None
    for cid, d in zip(c.loc[nm, "cdr_id"], c.loc[nm, "day"]):
        L.add("null_cell_site_id", "CDR", f"cdr_{day_str(d)}.csv", cid, "cell_site_id blank")
    nd = (rng.random(len(c)) < 0.002) & (c.call_type == "VOICE").to_numpy()
    c.loc[nd, "dur_out"] = pd.NA
    for cid, d in zip(c.loc[nd, "cdr_id"], c.loc[nd, "day"]):
        L.add("null_duration", "CDR", f"cdr_{day_str(d)}.csv", cid, "voice duration blank")
    ng = (rng.random(len(c)) < 0.001) & (c.call_type == "VOICE").to_numpy() & ~nd
    c.loc[ng, "dur_out"] = -c.loc[ng, "duration_sec"]
    for cid, d in zip(c.loc[ng, "cdr_id"], c.loc[ng, "day"]):
        L.add("negative_duration", "CDR", f"cdr_{day_str(d)}.csv", cid, "duration_sec negative")
    c["ord"] = np.arange(len(c), dtype=float)
    ex_idx = rng.choice(len(c), size=int(0.015 * len(c)), replace=False)
    ne_idx = rng.choice(len(c), size=int(0.010 * len(c)), replace=False)
    ex = c.iloc[ex_idx].copy(); ex["ord"] += 0.1
    ne = c.iloc[ne_idx].copy(); ne["ord"] += 0.2
    for cid, d in zip(ex.cdr_id, ex.day):
        L.add("duplicate_cdr_exact", "CDR", f"cdr_{day_str(d)}.csv", cid, "identical row repeated (same cdr_id)")
    orig_ids = ne.cdr_id.copy()
    ne["cdr_id"] = ne.cdr_id + "-RS"
    for nid, oid, d in zip(ne.cdr_id, orig_ids, ne.day):
        L.add("duplicate_cdr_near", "CDR", f"cdr_{day_str(d)}.csv", nid, f"resend of {oid} with new cdr_id")
    c = pd.concat([c, ex, ne]).sort_values("ord", kind="stable").reset_index(drop=True)
    cols = {"cdr_id": "cdr_id", "msisdn_out": "msisdn", "call_type": "call_type", "start_time": "start_time",
            "dur_out": "duration_sec", "data_mb": "data_mb", "site_out": "cell_site_id",
            "other_party_hash": "other_party_hash"}
    for d, grp in c.groupby("day"):
        grp[list(cols)].rename(columns=cols).to_csv(f"{D['structured/cdr']}/cdr_{day_str(d)}.csv", index=False)
    summary["cdr_rows_delivered"] = len(c)

    # ---------------------------------------------------------------- billing write
    lost_g = t[t.lost].groupby(["sub", "period"]).agg(lost_rows=("cdr_id", "count"), lost_mb=("data_mb", "sum"))
    b = b.merge(lost_g, how="left", left_on=["sub", "period"], right_index=True)
    b["lost_rows"] = b.lost_rows.fillna(0).astype(int)
    b["lost_mb"] = b.lost_mb.fillna(0).round(2)
    # a bill is only "explained by lost CDRs" when the lost usage is material (>2% of billed MB)
    material_loss = (b.lost_mb > 0.02 * b.true_cdr_mb.clip(lower=1))
    b["expected_recon_cause"] = np.where(b.flag != "", b.flag,
                                         np.where(material_loss, "cdr_records_lost", "match_within_rounding"))
    b[["bill_id", "msisdn", "period", "plan_id", "billed_calls", "true_cdr_minutes", "billed_minutes",
       "true_cdr_mb", "billed_mb", "billed_sms", "amount_inr", "lost_rows", "lost_mb", "expected_recon_cause"]] \
        .to_csv(f"{D['ground_truth']}/billing_recon_truth.csv", index=False)
    b["period_start"] = np.where(b.period == 1, "2026-09-01", "2026-09-08")
    b["period_end"] = np.where(b.period == 1, "2026-09-07", "2026-09-14")
    b["currency"] = "INR"
    late = (b.period == 2) & (rng.random(len(b)) < 0.10)
    b["extract_date"] = np.where(b.period == 1, "2026-09-09", np.where(late, "2026-09-20", "2026-09-16"))
    b["msisdn_out"], nv = msisdn_variants_vec(b.msisdn, rng, 0.15)
    L.add("msisdn_format_variant", "BILLING", "ALL", "*", f"{nv} rows with non-canonical MSISDN format")
    bcols = ["bill_id", "msisdn_out", "plan_id", "period_start", "period_end", "billed_calls", "billed_minutes",
             "billed_mb", "billed_sms", "amount_inr", "currency", "extract_date"]
    fN = {1: "billing_extract_2026-09-01_to_07.csv", 2: "billing_extract_2026-09-08_to_14.csv"}
    flate = "billing_extract_2026-09-08_to_14_late.csv"
    for bid in b.loc[late, "bill_id"]:
        L.add("late_billing_extract", "BILLING", flate, bid, "delivered 2026-09-20 instead of 2026-09-16")
    for p in (1, 2):
        part = b[(b.period == p) & ~late]
        dups = part.sample(frac=0.005, random_state=a.seed)
        for bid in dups.bill_id:
            L.add("duplicate_billing_row", "BILLING", fN[p], bid, "identical row repeated")
        part = pd.concat([part, dups]).sort_values("bill_id", kind="stable")
        part[bcols].rename(columns={"msisdn_out": "msisdn"}).to_csv(f"{D['structured/billing']}/{fN[p]}", index=False)
    b[late][bcols].rename(columns={"msisdn_out": "msisdn"}).to_csv(f"{D['structured/billing']}/{flate}", index=False)

    # ---------------------------------------------------------------- alarms
    A = []

    def add_alarm(site_no, el, atype, sev, raised, cleared, inc_id, text):
        A.append(dict(site=site_no, el=el, atype=atype, sev=sev, raised=raised, cleared=cleared, inc=inc_id, text=text))

    for inc in incs:
        s, t0, t1, k, iid = inc["site"], inc["start"], inc["end"], inc["kind"], inc["id"]
        ts = timedelta
        if k == "fiber_cut":
            add_alarm(s, "RTR", "PACKET_LOSS", "WARNING", t0 - ts(minutes=10), t0 + ts(seconds=10), iid, "Packet loss precursor")
            add_alarm(s, "RTR", "LINK_DOWN", "CRITICAL", t0 + ts(seconds=12), t1 + ts(minutes=1), iid, "Backhaul link down: loss of signal on fiber port")
            add_alarm(s, "RAN", "S1_LINK_FAILURE", "MAJOR", t0 + ts(seconds=45), t1 + ts(minutes=3), iid, "S1/NG interface failure")
            add_alarm(s, "RAN", "CELL_OUTAGE", "CRITICAL", t0 + ts(seconds=40), t1 + ts(minutes=3), iid, "Cell unavailable")
        elif k == "power_failure":
            add_alarm(s, "PWR", "MAINS_FAIL", "MAJOR", t0, t1 + ts(minutes=5), iid, "Mains supply lost")
            add_alarm(s, "PWR", "BATTERY_LOW", "MAJOR", t0 + ts(minutes=15), t1 + ts(minutes=5), iid, "Battery voltage critically low")
            add_alarm(s, "RAN", "CELL_OUTAGE", "CRITICAL", t0 + ts(minutes=20), t1 + ts(minutes=8), iid, "Cell unavailable: power loss")
        elif k == "software_upgrade_fault":
            add_alarm(s, "RAN", "SW_FAULT", "MAJOR", t0, t1 + ts(minutes=10), iid, "Software fault after upgrade window")
            add_alarm(s, "RAN", "LOW_THROUGHPUT", "WARNING", t0 + ts(minutes=2), t1 + ts(minutes=10), iid, "Throughput below baseline")
            for i in range(12):  # flapping
                r0 = t0 + ts(minutes=5 + i * 12)
                add_alarm(s, "RAN", "CELL_OUTAGE", "CRITICAL", r0, r0 + ts(minutes=R.randint(4, 8)), iid, "Cell restart detected")
        else:
            el, atype, cause = MINOR_ALARM[k]
            cycles = 4 if k == "link_flap" else 1
            span = (t1 - t0) / cycles
            for i in range(cycles):
                add_alarm(s, el, atype, "MINOR", t0 + span * i, t0 + span * i + span * 0.8, iid, cause)
            add_alarm(s, "RAN", "CELL_DEGRADED", "MAJOR", t0 + ts(minutes=5), t1, iid, "Cell performance degraded")
    for _ in range(3800):
        s = R.randint(1, N_SITES)
        el = R.choices(["RAN", "RTR", "PWR"], [.5, .3, .2])[0]
        atype, sev, cause = R.choice(BASE_ALARMS[el])
        raised = START_IST + timedelta(seconds=R.randint(0, DAYS * 86400 - 1))
        add_alarm(s, el, atype, sev, raised, raised + timedelta(minutes=max(1, R.lognormvariate(3.0, 0.9))),
                  "", cause)
    A.sort(key=lambda x: x["raised"])
    for i, x in enumerate(A):
        x["id"] = f"ALM-{i + 1:07d}"
    pd.DataFrame([{"alarm_id": x["id"], "cell_site_id": canon_site(x["site"]), "element_id": f"EL-{x['site']:04d}-{x['el']}",
                   "alarm_type": x["atype"], "severity": x["sev"], "raised_utc": fmt_z(x["raised"]),
                   "cleared_utc": fmt_z(x["cleared"]), "incident_id": x["inc"]} for x in A]) \
        .to_csv(f"{D['ground_truth']}/alarm_clean_truth.csv", index=False)
    summary["alarm_truth_rows"] = len(A)

    nxt = len(A) + 1
    emit = []
    for x in A:
        emit.append((x, x["id"], x["raised"], False))
        p = 0.35 if x["inc"] else 0.05
        k = 0
        while R.random() < p and k < 3:
            k += 1
            d = dict(x)
            nid = f"ALM-{nxt:07d}"; nxt += 1
            emit.append((d, nid, x["raised"] + timedelta(seconds=R.randint(1, 40)), True, x["id"]))
    emit.sort(key=lambda e: e[2])
    lines_by_day = {}
    el_code = {"RAN": "RAN", "RTR": "ROUTER", "PWR": "POWER"}
    sv, _ = site_variants_vec([e[0]["site"] for e in emit], rng, 0.04)
    for (e, sv_i) in zip(emit, sv):
        x, aid, raised, isdup = e[0], e[1], e[2], e[3]
        day = (raised.astimezone(IST).date() - START_IST.date()).days
        fname = f"alarms_{day_str(day)}.jsonl"
        el_id = f"EL-{x['site']:04d}-{x['el']}"
        if R.random() < 0.03:
            el_id = el_id.lower().replace("-", "_")
        fmt = fmt_ist_off if R.random() < 0.10 else fmt_z
        rec = {"alarm_id": aid, "element": {"id": el_id, "type": el_code[x["el"]]}, "site_id": sv_i,
               "severity": x["sev"], "alarm_type": x["atype"], "raised_ts": fmt(raised),
               "cleared_ts": fmt(x["cleared"] + (raised - x["raised"])), "probable_cause": x["text"],
               "additional_text": f"incident={x['inc']}" if False else ""}
        if isdup:
            L.add("duplicate_alarm", "ALARMS", fname, aid, f"re-send of {e[4]} within seconds, new alarm_id")
        u = R.random()
        line = None
        if u < 0.002:
            rec["severity"] = None
            L.add("null_severity", "ALARMS", fname, aid, "severity null")
        elif u < 0.004:
            rec["raised_ts"], rec["cleared_ts"] = rec["cleared_ts"], rec["raised_ts"]
            L.add("cleared_before_raised", "ALARMS", fname, aid, "cleared_ts earlier than raised_ts")
        line = json.dumps(rec)
        if R.random() < 0.003:
            line = line[:R.randint(25, len(line) - 8)]
            L.add("corrupt_json_truncated", "ALARMS", fname, aid, "line truncated mid-record")
        lines_by_day.setdefault(day, []).append(line)
    for day, ln in lines_by_day.items():
        with open(f"{D['semi_structured/alarms']}/alarms_{day_str(day)}.jsonl", "w") as f:
            f.write("\n".join(ln) + "\n")
    summary["alarm_lines_delivered"] = sum(len(v) for v in lines_by_day.values())

    # ---------------------------------------------------------------- usage events
    NIV = DAYS * 96
    S = np.repeat(site_nos, 3 * NIV)
    SEC = np.tile(np.repeat([1, 2, 3], NIV), N_SITES)
    IV = np.tile(np.arange(NIV), 3 * N_SITES)
    dw = HOUR_W / HOUR_W.mean()
    cap = rng.lognormal(np.log(1.5e9), 0.4, N_SITES + 1)
    share = np.array([.4, .35, .25])[SEC - 1]
    byt = cap[S] * dw[(IV % 96) // 4] * share * rng.lognormal(0, 0.15, len(S))
    mult = np.ones(len(S))
    dropm = np.zeros(len(S), bool)
    for inc in incs:
        iv0 = int((inc["impact_start"] - START_IST).total_seconds() // 900)
        iv1 = int(np.ceil((inc["end"] - START_IST).total_seconds() / 900))
        m = (S == inc["site"]) & (IV >= iv0) & (IV < iv1)
        if inc["kind"] == "fiber_cut":
            dropm |= m
            for sec_, iv_ in zip(SEC[m], IV[m]):
                L.add("missing_usage_interval", "USAGE_EVENTS",
                      f"usage_events_{day_str(iv_ // 96)}.jsonl",
                      f"{canon_site(inc['site'])}|sector{sec_}|{fmt_z(START_IST + timedelta(minutes=15 * int(iv_)))}",
                      f"{inc['id']}: element unreachable, no events sent")
        elif inc["kind"] == "power_failure":
            mult[m] = 0.02
        elif inc["kind"] == "software_upgrade_fault":
            mult[m] = 0.3
        else:
            mult[m] = 0.6
    byt = byt * mult
    rnd = (rng.random(len(S)) < 0.004) & ~dropm
    for s_, sec_, iv_ in zip(S[rnd], SEC[rnd], IV[rnd]):
        L.add("missing_usage_interval", "USAGE_EVENTS", f"usage_events_{day_str(iv_ // 96)}.jsonl",
              f"{canon_site(s_)}|sector{sec_}|{fmt_z(START_IST + timedelta(minutes=15 * int(iv_)))}",
              "random loss in transit")
    keep = ~(dropm | rnd)
    order = np.lexsort((SEC, S, IV))
    order = order[keep[order]]
    sessions = (byt / 5e6).astype(int)
    users = (sessions * rng.uniform(.5, .9, len(S))).astype(int)
    ul_share = rng.uniform(.08, .16, len(S))
    ts_utc = START_UTC_NAIVE + pd.to_timedelta(IV * 900, unit="s")
    ts_z = list(ts_utc.strftime("%Y-%m-%dT%H:%M:%SZ"))
    ts_ist = list((ts_utc + IST_OFFSET).strftime("%Y-%m-%dT%H:%M:%S+05:30"))
    svar, _ = site_variants_vec(S, rng, 0.03)
    rr = rng.random(len(S))
    ev_lines = {}
    for eid, i in enumerate(order, start=1):
        day = int(IV[i] // 96)
        fname = f"usage_events_{day_str(day)}.jsonl"
        total = int(byt[i])
        if day < DRIFT_DAY:
            rec = {"event_id": f"UE-{eid:08d}", "site_id": svar[i], "sector": int(SEC[i]), "interval_start": ts_z[i],
                   "interval_minutes": 15, "sessions": int(sessions[i]), "active_users": int(users[i]),
                   "bytes_total": total, "schema_version": "1.0"}
        else:
            ul = int(total * ul_share[i])
            rec = {"event_id": f"UE-{eid:08d}", "cell": {"site_id": svar[i], "sector": int(SEC[i])},
                   "interval_start_ts": ts_ist[i], "sessions": int(sessions[i]), "active_users": int(users[i]),
                   "traffic": {"ul_bytes": ul, "dl_bytes": total - ul}, "schema_version": "2.0"}
        u = rr[i]
        key = f"UE-{eid:08d}"
        if u < 0.0010:
            if day < DRIFT_DAY: rec["bytes_total"] = -abs(total)
            else: rec["traffic"]["dl_bytes"] = -abs(rec["traffic"]["dl_bytes"])
            L.add("negative_bytes", "USAGE_EVENTS", fname, key, "negative traffic value")
        elif u < 0.0015:
            if day < DRIFT_DAY: rec["site_id"] = None
            else: rec["cell"]["site_id"] = None
            L.add("null_site_id", "USAGE_EVENTS", fname, key, "site_id null")
        line = json.dumps(rec)
        if 0.0015 <= u < 0.0030:
            line = line[:R.randint(20, len(line) - 6)]
            L.add("corrupt_json_truncated", "USAGE_EVENTS", fname, key, "line truncated mid-record")
        ev_lines.setdefault(day, []).append(line)
        if 0.0030 <= u < 0.0050:
            ev_lines[day].append(line)
            L.add("duplicate_usage_event", "USAGE_EVENTS", fname, key, "identical event re-sent")
    for day, ln in ev_lines.items():
        with open(f"{D['semi_structured/usage_events']}/usage_events_{day_str(day)}.jsonl", "w") as f:
            f.write("\n".join(ln) + "\n")
        if day >= DRIFT_DAY:
            L.add("schema_drift", "USAGE_EVENTS", f"usage_events_{day_str(day)}.jsonl", "*",
                  "v2: bytes_total -> traffic.ul_bytes+dl_bytes; site_id -> cell.site_id; interval_start -> "
                  "interval_start_ts (+05:30 offset); interval_minutes removed; schema_version 2.0")
    summary["usage_event_lines"] = sum(len(v) for v in ev_lines.values())

    # ---------------------------------------------------------------- PDFs
    st = getSampleStyleSheet()
    body = st["BodyText"]

    def kv_table(rows, widths=(150, 330)):
        t_ = Table([[Paragraph(f"<b>{k}</b>", body), Paragraph(v, body)] for k, v in rows], colWidths=list(widths))
        t_.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                                ("BACKGROUND", (0, 0), (0, -1), colors.whitesmoke),
                                ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return t_

    for inc in incs:
        s = inc["site"]; name = LOCALITIES[s - 1]
        path = f"{D['unstructured/incident_reports']}/{inc['file']}"
        doc = SimpleDocTemplate(path, pagesize=A4, title=inc["id"])
        dmin = int((inc["end"] - inc["start"]).total_seconds() // 60)
        if inc["layout"] == "v1":
            els = [Paragraph("NETWORK INCIDENT REPORT", st["Title"]), Spacer(1, 10), kv_table([
                ("Incident ID", inc["id"]), ("Site ID", canon_site(s)), ("Site Name", name),
                ("Start Time (IST)", inc["start"].strftime("%Y-%m-%d %H:%M")),
                ("End Time (IST)", inc["end"].strftime("%Y-%m-%d %H:%M")), ("Severity", inc["severity"]),
                ("Root Cause", inc["root_cause"]), ("Resolution Action", inc["resolution"]),
                ("Customers Impacted (est.)", str(inc["impacted"]))])]
        else:
            L.add("document_layout_change", "INCIDENT_PDF", inc["file"], inc["id"],
                  "v2 layout: prose narrative, renamed labels (Ref/Location/Window), fields not in a key-value table")
            els = [Paragraph("Service Disruption Summary", st["Title"]),
                   Paragraph(f"Ref: {inc['id']} &nbsp;|&nbsp; Location: {name}", body), Spacer(1, 8),
                   Paragraph(f"On {inc['start'].strftime('%d %B %Y')}, between {inc['start'].strftime('%I:%M %p').lstrip('0')} "
                             f"and {inc['end'].strftime('%I:%M %p').lstrip('0')} IST, the tower serving {name} "
                             f"(cell site {canon_site(s)}) experienced a service disruption lasting about "
                             f"{dmin} minutes. This was classed as a {inc['severity'].lower()} event.", body), Spacer(1, 6),
                   Paragraph(f"Investigation found the underlying problem to be: {inc['root_cause'].lower()}. "
                             f"To fix it, the field and NOC teams carried out the following: {inc['resolution'].lower()}.", body),
                   Spacer(1, 6),
                   Paragraph(f"Roughly {inc['impacted']} subscribers homed on this site may have noticed degraded "
                             f"or unavailable service during the window.", body), Spacer(1, 12),
                   kv_table([("Ref", inc["id"]), ("Location", f"{name} ({canon_site(s)})"),
                             ("Window (IST)", f"{inc['start'].strftime('%d-%b-%Y %H:%M')} to {inc['end'].strftime('%H:%M')}"),
                             ("Subscribers affected (approx.)", str(inc["impacted"]))], widths=(200, 280))]
        doc.build(els)

    sla = {
        "PREPAID": ("Prepaid Consumer", 99.0, [(2, "no automatic credit; goodwill data pack at agent discretion"),
                                              (6, "1 day of plan validity added")]),
        "POSTPAID": ("Postpaid Consumer", 99.5, [(2, "5% rental credit for the affected billing week"),
                                                 (6, "10% rental credit for the affected billing week")]),
        "ENTERPRISE": ("Enterprise", 99.9, [(1, "10% rental credit for the affected billing week"),
                                            (4, "25% rental credit and a named incident review")]),
    }
    for seg_k, (title, avail, rules) in sla.items():
        doc = SimpleDocTemplate(f"{D['unstructured/service_agreements']}/SLA_{title.replace(' ', '_')}.pdf",
                                pagesize=A4, title=title)
        els = [Paragraph(f"Service Level Agreement - {title}", st["Title"]), Spacer(1, 10),
               Paragraph(f"<b>1. Availability target.</b> Network availability at the subscriber's home cell site "
                         f"will be at least {avail}% per calendar month.", body), Spacer(1, 6),
               Paragraph("<b>2. Service credits.</b> Credits apply to a continuous outage at the home cell site and "
                         "must be approved by a customer-service supervisor before being applied.", body), Spacer(1, 6)]
        for hrs, rule in rules:
            els.append(Paragraph(f"&bull; Outage longer than {hrs} hour(s): {rule}.", body))
        els += [Spacer(1, 6), Paragraph("<b>3. Billing adjustments.</b> Any billing adjustment requires human "
                                        "approval and an audit reference.", body)]
        doc.build(els)

    # ---------------------------------------------------------------- complaints
    inc_by_site = {i["site"]: i for i in incs}
    CAT = {
        "NO_SIGNAL": ["I have no network {where} since {when}. Phone shows no service, I can't make calls or use internet.",
                      "There is no signal {where} {when}. Calls and internet both completely dead.",
                      "Network went off {where} {when} and is still not back. Please check.",
                      "Network bilkul nahi aa raha hai {where} {when} se. Calls aur internet dono band hain."],
        "SLOW_DATA": ["Internet is extremely slow {where} since {when}. Even WhatsApp messages are not going.",
                      "Data speed is almost zero {where}. Videos keep buffering since {when}."],
        "CALL_DROP": ["My calls keep dropping {where} since {when}. I can't talk for more than a minute.",
                      "Voice is breaking and calls disconnect again and again {where} {when}."],
        "SMS_ISSUE": ["I am not receiving OTP and SMS messages {where} since {when}."],
        "BILLING_DISPUTE": ["My bill for this week is Rs {amt} which is much higher than normal. I did not use that much data. Please check and correct it.",
                            "I was charged Rs {amt} this week. This looks wrong, I want a billing review."],
        "PLAN_QUERY": ["I want to know my remaining data balance and when my plan expires.",
                       "Can you tell me the benefits of my current plan?"],
    }
    SERVICE = {"NO_SIGNAL": "VOICE_AND_DATA", "SLOW_DATA": "DATA", "CALL_DROP": "VOICE", "SMS_ISSUE": "SMS",
               "BILLING_DISPUTE": "BILLING", "PLAN_QUERY": "GENERAL"}
    AGENT_LINKED = {
        "fiber_cut": "I can see a backhaul connectivity problem on the tower near {area}. Our field team is working on it.",
        "power_failure": "There is a power issue at the tower serving {area}. Engineers are on the way.",
        "software_upgrade_fault": "We are seeing instability on your cell after recent maintenance work. Our team is fixing it.",
        "hardware_overtemp": "We have detected a technical fault on the tower near you and engineers are informed.",
        "clock_sync": "We have detected a technical fault on the tower near you and engineers are informed.",
        "antenna_vswr": "We have detected a technical fault on the tower near you and engineers are informed.",
        "link_flap": "We have detected a technical fault on the tower near you and engineers are informed.",
    }

    def when_phrase(dt):
        h = dt.hour
        h12 = h % 12 or 12
        ap_ = "AM" if h < 12 else "PM"
        exact = f"{h12}:{dt.minute:02d} {ap_}" if R.random() < .4 else f"{h12} {ap_}"
        bucket = ("this morning" if 5 <= h < 12 else "this afternoon" if 12 <= h < 17
                  else "this evening" if 17 <= h < 21 else "tonight")
        return R.choice([f"around {exact}", exact, bucket])

    plan_c = []
    for inc in incs:
        s = inc["site"]
        pool = subs_by_site.get(s, [])
        if not pool:
            continue
        nC = R.randint(20, 30) if inc["severity"] == "MAJOR" else R.randint(1, 2)
        mix = (["NO_SIGNAL"] * 12 + ["CALL_DROP"] * 4 + ["SLOW_DATA"] * 3 + ["SMS_ISSUE"]) if inc["severity"] == "MAJOR" \
            else ["SLOW_DATA", "CALL_DROP", "NO_SIGNAL"]
        if inc["kind"] == "software_upgrade_fault":
            mix = ["SLOW_DATA"] * 8 + ["CALL_DROP"] * 6 + ["NO_SIGNAL"] * 4 + ["SMS_ISSUE"]
        span = max(30, int((inc["end"] - inc["impact_start"]).total_seconds() // 60)) + (120 if inc["severity"] == "MAJOR" else 30)
        for _ in range(nC):
            recv = inc["impact_start"] + timedelta(minutes=R.randint(15, span))
            plan_c.append(dict(sub=R.choice(pool), cat=R.choice(mix), recv=recv, inc=inc,
                               when_dt=inc["impact_start"] + timedelta(minutes=R.randint(0, 10))))
    over_subs = list(b.loc[b.flag == "billing_overcharge", ["sub", "period", "amount_inr"]].itertuples(index=False))
    R.shuffle(over_subs)
    ok_rows = list(b.loc[(b.flag == "") & (b.amount_inr > 0), ["sub", "period", "amount_inr"]].sample(12, random_state=a.seed).itertuples(index=False))
    bg = [("BILLING_DISPUTE", r, True) for r in over_subs[:20]] + [("BILLING_DISPUTE", r, False) for r in ok_rows]
    bg += [(c_, None, None) for c_ in ["SLOW_DATA"] * 12 + ["CALL_DROP"] * 12 + ["PLAN_QUERY"] * 8 + ["SMS_ISSUE"] * 6]
    for cat, row, true_over in bg:
        recv = START_IST + timedelta(seconds=R.randint(86400 // 2, DAYS * 86400 - 3600))
        if row is not None:
            recv = START_IST + timedelta(days=(7 if row.period == 1 else 14), hours=R.randint(1, 20), minutes=R.randint(0, 59)) \
                if row.period == 1 else START_IST + timedelta(days=13, hours=R.randint(20, 23), minutes=R.randint(0, 59))
        plan_c.append(dict(sub=row.sub if row is not None else R.randrange(N_SUBS), cat=cat, recv=recv, inc=None,
                           when_dt=recv - timedelta(hours=R.randint(1, 20)), amt=getattr(row, "amount_inr", None),
                           over=true_over))
    plan_c.sort(key=lambda x: x["recv"])
    comp, ctruth = [], []
    for i, cd in enumerate(plan_c):
        cid = f"CMP-{i + 1:06d}"
        sub_i = cd["sub"]
        home = int(home_site[sub_i])
        area = LOCALITIES[home - 1]
        where = R.choice([f"in {area}", f"near {area}", f"around {area} area"]) if R.random() < 0.7 else ""
        cat = cd["cat"]
        text = R.choice(CAT[cat]).format(where=where, when=when_phrase(cd["when_dt"]), amt=cd.get("amt"))
        text = " ".join(text.split())
        secondary = ""
        if R.random() < 0.10 and cat in ("NO_SIGNAL", "SLOW_DATA", "CALL_DROP"):
            secondary = "PLAN_QUERY"
            text += " Also, " + R.choice(CAT["PLAN_QUERY"]).lower()
        inc = cd["inc"]
        if inc is not None:
            agent = AGENT_LINKED[inc["kind"]].format(area=area) if R.random() < 0.6 else "I am sorry for the inconvenience. I have escalated this to our network team."
            root = inc["kind"]; res = "escalated_to_network_ops"
        elif cat == "BILLING_DISPUTE":
            root = "billing_overcharge" if cd.get("over") else "customer_misunderstanding"
            res = "billing_adjustment_review" if cd.get("over") else "explained_charges"
            agent = "Let me review your usage and charges for the week."
        elif cat == "PLAN_QUERY":
            root, res, agent = "none", "information_provided", "Sure, let me pull up your plan details."
        else:
            root, res, agent = "customer_device_issue", "standard_troubleshooting", "Please restart your phone and re-insert the SIM card."
        ms = str(msisdns[sub_i])
        chan = R.choices(["CALL_CENTER", "APP", "EMAIL", "SOCIAL"], [.55, .20, .15, .10])[0]
        mention = f"My number is {msisdn_variant(ms, R)}." if R.random() < 0.4 else ""
        cust_ref = msisdn_variant(ms, R) if R.random() > 0.08 else None
        if chan == "CALL_CENTER":
            tr = (f"Agent: Thank you for calling customer care. How can I help you?\nCustomer: {text} {mention}\n"
                  f"Agent: {agent}\nCustomer: Okay, please do the needed.\n"
                  f"Agent: Your ticket number is TKT-{R.randint(10000, 99999)}. Is there anything else?\nCustomer: No, thanks.")
        else:
            tr = f"{text} {mention}".strip()
        if cust_ref is None and not mention:
            tr += f" My number is {msisdn_variant(ms, R)}."
        comp.append({"complaint_id": cid, "channel": chan, "received_at": fmt_ist_off(cd["recv"]),
                     "customer_msisdn": cust_ref, "transcript": tr})
        ctruth.append({"complaint_id": cid, "true_msisdn": ms, "true_cell_site_id": canon_site(home),
                       "true_incident_id": inc["id"] if inc else "", "true_category": cat,
                       "true_secondary_category": secondary, "true_affected_service": SERVICE[cat],
                       "true_root_cause": root, "true_resolution_action": res})
    with open(f"{D['unstructured/complaints']}/complaints.jsonl", "w") as f:
        f.write("\n".join(json.dumps(c_) for c_ in comp) + "\n")
    pd.DataFrame(ctruth).to_csv(f"{D['ground_truth']}/complaint_truth.csv", index=False)
    summary["complaints"] = len(comp)
    summary["incident_pdfs"] = len(incs)
    summary["sla_pdfs"] = len(sla)

    # ---------------------------------------------------------------- ledger + summary
    ldf = L.write(f"{D['ground_truth']}/fault_ledger.csv")
    summary["fault_ledger_rows"] = len(ldf)
    summary["faults_by_type"] = ldf.fault_type.value_counts().to_dict()
    with open(f"{out}/generation_summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=int)
    print(json.dumps(summary, indent=2, default=int))


if __name__ == "__main__":
    main()
