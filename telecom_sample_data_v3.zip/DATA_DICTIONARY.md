# Telecom capstone sample data - data dictionary
Seed 42 | 2,000 subscribers | 50 cell sites (150 network elements) | 14 days, 2026-09-01 to 2026-09-14 (business day = IST) | Regenerate: `python3 generate_telecom_data.py --out output --seed 42`

## Sources (feed these to the pipeline)
| Path | Format | Notes |
|---|---|---|
| masters/cell_site_master.csv, network_element_master.csv, subscriber_master.csv, plan_rate_card.csv | CSV | Canonical keys: `CELL-0017`, `EL-0017-RAN`, 12-digit `91XXXXXXXXXX` MSISDN |
| structured/cdr/cdr_YYYYMMDD.csv | CSV | ~19k rows/day. Mixed timestamp formats (ISO UTC / `dd/mm/yyyy HH:MM:SS` IST / epoch), MSISDN and cell-site ID variants |
| structured/billing/*.csv | CSV | Weekly extracts (period 1 = Sep 1-7, period 2 = Sep 8-14) + one late file. Billed from the TRUE usage, so billed vs cleaned-CDR can be reconciled |
| semi_structured/alarms/alarms_YYYYMMDD.jsonl | JSONL | Nested element object, UTC or +05:30 timestamps, duplicate alarms with new IDs, a few truncated lines |
| semi_structured/usage_events/usage_events_YYYYMMDD.jsonl | JSONL | 15-min per site-sector. v1.0 until Sep 7; v2.0 from Sep 8 (schema drift) |
| unstructured/complaints/complaints.jsonl | JSONL | Call-centre transcripts + short app/email/social text; free-text time and location, one Hinglish template |
| unstructured/incident_reports/*.pdf | PDF | 16 reports. Layout v1 (key-value table) before Sep 8, layout v2 (prose narrative, renamed labels) from Sep 8 |
| unstructured/service_agreements/*.pdf | PDF | SLA credit rules per segment |

## Planted story (ground_truth/incident_truth.csv)
INC-0001 Site 17 fiber cut Sep 3 14:00-16:30 | INC-0006 Site 8 power failure Sep 7 02:00-05:00 | INC-0013 Site 31 software-upgrade fault Sep 11 18:00-20:30 + 13 minor incidents.
Each major incident produces alarms (with duplicates/flapping), missing or reduced usage events, dropped CDRs, a complaint burst and an incident PDF.

## Ground truth (NEVER feed to the pipeline - use it to score it)
fault_ledger.csv (every injected fault) | incident_truth.csv | alarm_clean_truth.csv | cdr_clean_truth.csv.gz | billing_recon_truth.csv (expected reconciliation outcome per bill) | complaint_truth.csv (expected extraction + linked incident)

## Fault -> demo scenario
Missing events: missing_usage_interval, cdr_record_lost | Duplicates: duplicate_cdr_exact/near, duplicate_alarm, duplicate_usage_event, duplicate_billing_row | Drift: schema_drift, timestamp_format_mix, *_format_variant | Corrupt: corrupt_json_truncated, negative_bytes, negative_duration, null_* , cleared_before_raised | Layout change: document_layout_change | Billing: billing_overcharge/undercharge, late_billing_extract
